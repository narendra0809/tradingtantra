import React from 'react'
import Notifications from '../../Components/Dashboard/Notifications'

const NotificationPage = () => {
  return (
    <div>

        <Notifications />
    </div>
  )
}

export default NotificationPage